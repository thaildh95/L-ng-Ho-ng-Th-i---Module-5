export interface IRatingUnit {
  value: number;
  active: boolean;
}
